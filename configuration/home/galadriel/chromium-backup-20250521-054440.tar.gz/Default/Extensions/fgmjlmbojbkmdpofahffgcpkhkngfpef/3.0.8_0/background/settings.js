/**
 * Default settings configuration for the extension.
 * These values are used when initializing the extension for the first time
 * or if the settings are missing from storage.
 */
const SETTINGS = {
  hasParsedExtensionHeaders: false,
  hasSeenSerpOnboarding: false,
};

/**
 * Updates a specific setting in chrome.storage.local
 * @param {string} key - The setting key to update
 * @param {any} value - The new value to store
 * @returns {Promise} - Chrome storage set operation
 */
const setSetting = async (key, value) => {
  const settingsObj = await chrome.storage.local.get(['settings']);
  const settings = settingsObj.settings;
  settings[key] = value
  return chrome.storage.local.set({ settings });
};

/**
 * Retrieves a specific setting from chrome.storage.local
 * @param {string} key - The setting key to retrieve
 * @returns {Promise<any>} - The value of the requested setting
 */
const getSetting = async (key) => {
  const settingsObj = await chrome.storage.local.get(['settings']);
  const settings = settingsObj.settings;
  return settings[key];
};

/**
 * Message handler for settings-related operations.
 * Supports:
 * - getSettings: Retrieves a setting value
 * - setSettings: Updates a setting value
 * Returns true to enable async response handling
 */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.event) {
    case "setSetting":
      setSetting(msg.key, msg.value);
      // sending a response here is a good practice
      // to prevent async errors in the content script
      sendResponse({
        message: "Setting updated",
        key: msg.key,
        value: msg.value,
      });
      break;
      
    case "getSetting":
      getSetting(msg.key).then(result => {
        sendResponse(result);
      });
      break;
      
    default:
      break;
  }
  return true; // Required to use sendResponse asynchronously
});

/**
 * Ensures settings exist in storage when extension is installed or updated.
 * If no settings are found, initializes them with default values.
 */
chrome.runtime.onInstalled.addListener(async () => {
  const settingsObj = await chrome.storage.local.get(['settings']);
  if (!settingsObj.settings) {
    await chrome.storage.local.set({ settings: SETTINGS });
  }
});
