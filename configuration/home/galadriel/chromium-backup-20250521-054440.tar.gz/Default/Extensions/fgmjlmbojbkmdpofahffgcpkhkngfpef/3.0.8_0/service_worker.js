importScripts(
  "./background/settings.js",
  "./background/healthcheck.js",
  "./background/main.js"
);
