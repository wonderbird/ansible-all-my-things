// Constants for extension identification and default installation parameters
const EXT_LABEL = "ext-chrome";
const SEGMENT = "startpage.defaultchx";
const INSTALL_PARAMS = {
  source: "organic",
  campaign: "none",
  date: "2000-01-01",
  account: "none",
  act: "none",
};

/**
 * Gets the user's language code (supports only 'en' and 'de')
 * @returns {string} Language code ('en' or 'de')
 */
const getLangCode = () => {
  const lang = chrome.i18n.getUILanguage().split("-")[0];
  return lang === "de" ? lang : "en";
}

/**
 * Updates the declarative network request rules for header modification
 * @param {Object} updateParams - Parameters to update the headers with
 */
const updateHeaderRules = (updateParams) => {
  // Rule 1: Adds basic extension headers to all HTTP requests
  const RULE_1 = {
    id: 1,
    priority: 1,
    condition: {
      urlFilter: "|http*",
      resourceTypes: ["main_frame"],
    },
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        { header: "Startpage-Extension", operation: "set", value: EXT_LABEL },
        {
          header: "Startpage-Extension-Version",
          operation: "set",
          value: chrome.runtime.getManifest().version,
        },
        {
          header: "Startpage-Extension-Segment",
          operation: "set",
          value: SEGMENT,
        },
      ],
    },
  };

  // Rule 2: Adds additional tracking headers for search requests
  const RULE_2 = {
    id: 2,
    priority: 2,
    condition: {
      urlFilter: "/do/dsearch",
      resourceTypes: ["main_frame"],
    },
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        ...RULE_1.action.requestHeaders,  // Include basic headers
        {
          header: "Startpage-Extension-Campaign",
          operation: "set",
          value: updateParams["campaign"],
        },
        {
          header: "Startpage-Extension-Date",
          operation: "set",
          value: updateParams["date"],
        },
        {
          header: "Startpage-Extension-Source",
          operation: "set",
          value: updateParams["source"],
        },
        {
          header: "Startpage-Extension-Account",
          operation: "set",
          value: updateParams["account"],
        },
        {
          header: "Startpage-Extension-Act",
          operation: "set",
          value: updateParams["act"],
        },
      ],
    },
  };

  // Update both rules in the Chrome declarative request system
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [RULE_1.id],
    addRules: [RULE_1],
  });
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [RULE_2.id],
    addRules: [RULE_2],
  });
}

/**
 * Handles successful extension installation
 * sets the uninstall url and opens the success page
 * @param {string} reason - Installation reason
 */
const launchSuccess = (reason) => {
  if (reason !== "install") return;

  chrome.storage.local.get(INSTALL_PARAMS, (data) => {
    const lang = getLangCode();
    updateUninstallUrl(lang, data);
    chrome.tabs.create({ url: `https://add.startpage.com/${lang}/success/` });
  });
}

/**
 * Updates the uninstall URL with tracking parameters
 * @param {string} lang - Language code
 * @param {Object} params - Tracking parameters
 */
const updateUninstallUrl = (lang, params) => {
  const urlBase = `https://add.startpage.com/${lang}/uninstall/`;
  const u = buildUrl(urlBase, params);
  chrome.runtime.setUninstallURL(u);
}

/**
 * Builds a URL with tracking parameters
 * @param {string} base - Base URL
 * @param {Object} data - Tracking parameters to add
 * @returns {string} Complete URL with parameters
 */
const buildUrl = (base, data) => {
  const u = new URL(base);
  u.searchParams.set("pl", EXT_LABEL);
  u.searchParams.set("segment", SEGMENT);
  u.searchParams.set("extVersion", chrome.runtime.getManifest().version);
  u.searchParams.set("campaign", `${data.campaign}_${data.act}`);
  u.searchParams.set("date", data.date);
  u.searchParams.set("source", data.source);
  u.searchParams.set("account", data.account);
  return u.toString();
}

// Handle extension icon click - open Startpage
chrome.action.onClicked.addListener(() =>
  chrome.tabs.create({ url: "https://www.startpage.com/" })
);

// Handle extension installation
chrome.runtime.onInstalled.addListener((e) => launchSuccess(e.reason));

// Listen for changes in local storage to update header rules and uninstall URL
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace !== "local") return;

  chrome.storage.local.get(INSTALL_PARAMS, (data) => {
    const currentParams = { ...data };
    for (const key of Object.keys(changes)) {
      currentParams[key] = changes[key].newValue;
    }
    updateHeaderRules(currentParams);
    updateUninstallUrl(getLangCode(), currentParams);
  });
});

/**
 * Message handler for extension header (aka INSTALL_PARAMS) related operations.
 * Supports:
 * - setExtensionHeaders: Sets extension headers
 * - getExtensionHeaders: Retrieves extension headers
 * Returns true to enable async response handling
 *
 * @param {Object} msg - Message object containing event and parameters
 * @param {string} msg.event - Event name
 * @param {Object} msg.params - Campaign parameters
 */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.event) {
    case "setExtensionHeaders":
      chrome.storage.local.get(INSTALL_PARAMS, (data) => {
        const args = Object.keys(INSTALL_PARAMS).reduce(
          (acc, param) => {
            acc[param] = msg[param] || acc[param];
            return acc;
          },
          { ...INSTALL_PARAMS }
        );
        updateHeaderRules(args);
        chrome.storage.local.set(args);
        // sending a response here is good practice
        // to prevent async errors in the content script
        sendResponse({
          message: "Extension headers set",
          data: args,
        });
      });
      break;

    case "getExtensionHeaders":
      chrome.storage.local.get(INSTALL_PARAMS, (data) => {
        sendResponse({
          ...data,
        });
      });
      break;

    default:
      break;
  }
  return true; // Required to use sendResponse asynchronously
});
