// Health check constants
const HEALTH_CHECK_STATUS = {
  active: true,
  version: chrome.runtime.getManifest().version,
  lastChecked: Date.now(),
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.event === "healthCheck") {
    HEALTH_CHECK_STATUS.lastChecked = Date.now();
    sendResponse({
      status: "healthy",
      active: HEALTH_CHECK_STATUS.active,
      version: HEALTH_CHECK_STATUS.version,
      timestamp: HEALTH_CHECK_STATUS.lastChecked,
    });
  }
  return true; // Required to use sendResponse asynchronously
});
