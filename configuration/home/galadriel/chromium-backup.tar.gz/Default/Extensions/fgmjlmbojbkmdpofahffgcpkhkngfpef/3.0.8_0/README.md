# StartPage Search

This add-on adds StartPage Search Engine to the browser.

Makes Startpage the default search engine for startpage.com after user confirmation.

Can add declarativeNetRequestFeedback to manifest permissions to utlize below code for testing headers in unpacked form. (Add below code in main.js to use)

Leaving this out in production build for less risk of getting rejected to the web store.

```
chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((e) => {
  const msg = `Headers in request to ${e.request.url} modified.`;
  console.log(msg);
});
```
