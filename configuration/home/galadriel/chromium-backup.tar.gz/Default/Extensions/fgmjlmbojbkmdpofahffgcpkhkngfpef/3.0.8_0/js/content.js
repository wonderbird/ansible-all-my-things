/**
 * CONSTANTS
 * These constants define key settings and CSS classes used throughout the extension
 */
const SETTINGS_KEYS = {
  // Tracks whether the user has seen the search results page (SERP) onboarding
  HAS_PARSED_EXTENSION_HEADERS: "hasParsedExtensionHeaders",
  HAS_SEEN_SERP_ONBOARDING: "hasSeenSerpOnboarding",
};

const CLASSES = {
  // CSS class added to body to indicate the extension is installed
  SEARCH_PLUGIN_ADDED: "search_plugin_added",
  // CSS class added to body after user has seen the SERP onboarding
  SEARCH_PLUGIN_HAS_SEEN_ONBOARDING: "search_plugin_has_seen_onboarding",
};

/**
 * HELPER FUNCTIONS
 * These functions handle communication with the extension's background service_worker.js script
 */

/**
 * Retrieves a setting value from the extension's storage
 * @param {string} key - The settings key to retrieve
 * @returns {Promise<any>} The value stored for the given key
 */
const getSetting = async (key) => {
  return await chrome.runtime.sendMessage({
    event: "getSetting",
    key: key,
  });
};

/**
 * Saves a setting value to the extension's storage
 * @param {string} key - The settings key to save
 * @param {any} value - The value to store
 * @returns {Promise<void>}
 */
const setSetting = async (key, value) => {
  await chrome.runtime.sendMessage({
    event: "setSetting",
    key: key,
    value: value,
  });
};

/**
 * Retrieves extension headers from the background script
 * @returns {Promise<Object>} The extension headers
 */
const getExtensionHeaders = async () => {
  return await chrome.runtime.sendMessage({
    event: "getExtensionHeaders",
  });
};

/**
 * Sends extension headers to the background script
 * @param {Object} headers - The extension headers to send
 */
const setExtensionHeaders = (headers) => {
  chrome.runtime.sendMessage({
    event: "setExtensionHeaders",
    ...headers,
  });
};

/**
 * MAIN FUNCTIONALITY
 * Core functions that implement the extension's features
 */

/**
 * Adds a CSS class to the body element to indicate the extension is installed.
 * This visual indicator is used across all Startpage.com domains.
 */
const addExtensionInstalledIndicator = () => {
  document.body.classList.add(CLASSES.SEARCH_PLUGIN_ADDED);
};

/**
 * Initializes extension headers on the post-installation success page.
 * Reads installation metadata from localStorage and sends it to the background script.
 * This data is used for tracking installation analytics and extension revenue attribution on the SERP.
 */
const initExtensionHeaders = async () => {
  const hasParsedExtensionHeaders = await getSetting(SETTINGS_KEYS.HAS_PARSED_EXTENSION_HEADERS);
  if (hasParsedExtensionHeaders) {
    return;
  }

  const store = window.localStorage;
  let fields;

  // Safely parse extension metadata from localStorage
  try {
    fields = JSON.parse(store.getItem("extMeta")) || {};
  } catch (ex) {
    fields = {};
  }

  // Prepare installation data for analytics
  const data = {
    campaign: fields.campaign,
    date: fields.date,
    source: fields.source,
    account: fields.account,
    act: fields.act,
  };

  /* Send installation data to background script (service worker) and mark extension as loaded
   * This will trigger the setExtensionHeaders event in the background script
   * and set the extension headers on every SERP request.
   */
  setExtensionHeaders(data);
  store.setItem("extLoaded", "true");
  // Mark that the extension headers have been parsed to prevent duplicate parsing on subsequent success page visits
  setSetting(SETTINGS_KEYS.HAS_PARSED_EXTENSION_HEADERS, true);
}

/**
 * Handles the SERP (Search Engine Results Page) onboarding experience.
 * Checks if the user has seen the onboarding before and updates the UI accordingly.
 * If it's the first visit, marks the onboarding as seen.
 */
const initSerpOnboarding = async () => {
  const hasSeenSerpOnboarding = await getSetting(SETTINGS_KEYS.HAS_SEEN_SERP_ONBOARDING);

  if (hasSeenSerpOnboarding) {
    document.body.classList.add(CLASSES.SEARCH_PLUGIN_HAS_SEEN_ONBOARDING);
  } else {
    setSetting(SETTINGS_KEYS.HAS_SEEN_SERP_ONBOARDING, true);
  }
};

const logDpl = (event = "StartpageExtensionRetention", payload = {}) => {
  const i = new Image();
  const om_event = encodeURIComponent(
    JSON.stringify([
      {
        event,
        product: "STARTPAGE",
        payload,
      },
    ])
  );
  i.src = "https://www.startpage.com/sp/dplpxs?om_event=" + om_event;
};

/**
 * Pings the background script's health check endpoint
 * Processes the health check request and responds with the extension's status
 */
const pingHealthCheck = async () => {
  try {
    const response = await chrome.runtime.sendMessage({
      event: "healthCheck"
    });
    return response;
  } catch (err) {
    return {
      status: "error",
      error: "Extension communication failed",
      timestamp: Date.now()
    };
  }
};

/**
 * Polls the background script's health check endpoint periodically
 * to verify the extension is still active and functioning
 * and logs the extension retention event when the user closes the page
 */
const initLogStartpageExtensionRetention = async () => {
  let isAlive = false;
  const hasSeenSerpOnboarding = await getSetting(SETTINGS_KEYS.HAS_SEEN_SERP_ONBOARDING);
  if (hasSeenSerpOnboarding) {
    return;
  }

  // cache headers here to avoid extra calls to the background script
  const headers = await getExtensionHeaders();

  const intervalId = setInterval(async () => {
    const healthCheckResponse = await pingHealthCheck();
    const isActive = Boolean(healthCheckResponse.active);
    isAlive = isActive;
    if (!isActive) {
      clearInterval(intervalId);
    }
  }, 500); // Poll every .5 seconds

  window.addEventListener("beforeunload", () => {
    const payload = {
      ...headers,
      isAlive
    };
    logDpl("StartpageExtensionRetention", payload);
  });
};

/**
 * INITIALIZATION
 * that runs when the content script loads
 */
addExtensionInstalledIndicator();

(function () {
  // Parse current URL to determine which page we're on
  const u = new URL(document.URL);
  const { hostname, pathname } = u;

  // Check if we're on the success page or search results page
  const isSuccessPage = hostname === 'add.startpage.com' && pathname.endsWith('/success/');
  const isSerpPage = hostname.includes("startpage.com") && pathname.startsWith("/do/dsearch");

  // Initialize appropriate features based on the current page
  if (isSuccessPage) {
    initExtensionHeaders();
  }
  if (isSerpPage) {
    initSerpOnboarding();
    initLogStartpageExtensionRetention();
  }
})();
